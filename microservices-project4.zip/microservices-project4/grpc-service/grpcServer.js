const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');
const PROTO_PATH = './proto/user.proto';

// Charger le fichier .proto
const packageDefinition = protoLoader.loadSync(PROTO_PATH, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});


const users = []; // Tableau pour stocker les utilisateurs

// Implémentation des fonctions gRPC
function createUser(call, callback) {
  const user = call.request;
  user.id = users.length + 1;
  users.push(user);
  callback(null, user);
}

function getUsers(call, callback) {
  callback(null, { users });
}

function getUser(call, callback) {
  const user = users.find(u => u.id == call.request.id);
  if (user) {
    callback(null, user);
  } else {
    callback({
      code: grpc.status.NOT_FOUND,
      details: 'Utilisateur non trouvé',
    });
  }
}

const server = new grpc.Server();
server.addService(userProto.UserService.service, {
  createUser,
  getUsers,
  getUser,
});

server.bindAsync('127.0.0.1:50051', grpc.ServerCredentials.createInsecure(), () => {
  console.log('gRPC Server en écoute sur le port 50051');
  server.start();
});
