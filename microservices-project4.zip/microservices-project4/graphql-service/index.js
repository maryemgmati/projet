const express = require('express');
const { ApolloServer, gql } = require('apollo-server-express');

const typeDefs = gql`
  type Product {
    id: ID!
    name: String!
    price: Float!
  }

  type Query {
    products: [Product]
    product(id: ID!): Product
  }

  type Mutation {
    addProduct(name: String!, price: Float!): Product
    updateProduct(id: ID!, name: String, price: Float): Product
    deleteProduct(id: ID!): Boolean
  }
`;

let products = [
  { id: '1', name: 'Product 1', price: 100.0 },
  { id: '2', name: 'Product 2', price: 200.0 },
];

const resolvers = {
  Query: {
    products: () => products,
    product: (parent, args) => products.find(product => product.id === args.id),
  },
  Mutation: {
    addProduct: (parent, args) => {
      const newProduct = { id: `${products.length + 1}`, name: args.name, price: args.price };
      products.push(newProduct);
      return newProduct;
    },
    updateProduct: (parent, args) => {
      const product = products.find(product => product.id === args.id);
      if (product) {
        if (args.name !== undefined) product.name = args.name;
        if (args.price !== undefined) product.price = args.price;
      }
      return product;
    },
    deleteProduct: (parent, args) => {
      const productIndex = products.findIndex(product => product.id === args.id);
      if (productIndex > -1) {
        products.splice(productIndex, 1);
        return true;
      }
      return false;
    },
  },
};

const server = new ApolloServer({ typeDefs, resolvers });

const app = express();

async function startApolloServer() {
  await server.start();
  server.applyMiddleware({ app });
}

startApolloServer().then(() => {
  const PORT = 4000;
  app.listen(PORT, () => {
    console.log(`🚀 Server ready at http://localhost:${PORT}${server.graphqlPath}`);
  });
});
