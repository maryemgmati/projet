const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');

const app = express();

app.use('/rest', createProxyMiddleware({ target: 'http://localhost:3000', changeOrigin: true }));
app.use('/graphql', createProxyMiddleware({ target: 'http://localhost:4000', changeOrigin: true }));
app.use('/grpc', createProxyMiddleware({ target: 'http://localhost:50051', changeOrigin: true }));

app.listen(8080, () => {
  console.log('API Gateway running on port 8080');
});
