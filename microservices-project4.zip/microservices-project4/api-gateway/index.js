const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');

const app = express();
const PORT = process.env.PORT || 5000; // Utilisez le port 5000

// Middleware de journalisation pour toutes les requêtes
app.use((req, res, next) => {
  console.log(`${req.method} ${req.url}`);
  next();
});

// Proxy pour le product-service (REST)
app.use('/api/products', createProxyMiddleware({
  target: 'http://localhost:3000',
  changeOrigin: true,
  logLevel: 'debug', // Ajout de logs pour le débogage
  onProxyReq: (proxyReq, req, res) => {
    console.log(`Proxying request to: ${proxyReq.path}`);
  },
  onError: (err, req, res) => {
    console.error('Error occurred while trying to proxy:', err);
    res.status(500).send('Proxy error');
  }
}));

// Proxy pour le graphql-service (GraphQL)
app.use('/graphql', createProxyMiddleware({
  target: 'http://localhost:4000',
  changeOrigin: true,
  logLevel: 'debug', // Ajout de logs pour le débogage
  onProxyReq: (proxyReq, req, res) => {
    console.log(`Proxying request to: ${proxyReq.path}`);
  },
  onError: (err, req, res) => {
    console.error('Error occurred while trying to proxy:', err);
    res.status(500).send('Proxy error');
  }
}));

// Route par défaut pour la racine
app.get('/', (req, res) => {
  res.send('Bienvenue sur l\'API Gateway. Utilisez /api/products pour le product-service et /graphql pour le graphql-service.');
});

app.listen(PORT, () => {
  console.log(`API Gateway fonctionne sur le port ${PORT}`);
});
