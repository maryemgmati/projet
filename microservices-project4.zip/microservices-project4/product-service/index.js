const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(cors());

let products = []; // Tableau pour stocker les produits

// Endpoint pour créer un nouveau produit
app.post('/products', (req, res) => {
  const product = req.body;
  product.id = products.length + 1;
  products.push(product);
  res.status(201).send(product);
});

// Endpoint pour récupérer tous les produits
app.get('/products', (req, res) => {
  res.send(products);
});

// Endpoint pour récupérer un produit par ID
app.get('/products/:id', (req, res) => {
  const product = products.find(p => p.id == req.params.id);
  if (product) {
    res.send(product);
  } else {
    res.status(404).send({ message: 'Produit non trouvé' });
  }
});

// Endpoint pour mettre à jour un produit par ID
app.put('/products/:id', (req, res) => {
  const product = products.find(p => p.id == req.params.id);
  if (product) {
    Object.assign(product, req.body);
    res.send(product);
  } else {
    res.status(404).send({ message: 'Produit non trouvé' });
  }
});

// Endpoint pour supprimer un produit par ID
app.delete('/products/:id', (req, res) => {
  const productIndex = products.findIndex(p => p.id == req.params.id);
  if (productIndex > -1) {
    products.splice(productIndex, 1);
    res.status(204).send();
  } else {
    res.status(404).send({ message: 'Produit non trouvé' });
  }
});

app.listen(PORT, () => {
  console.log(`Le product-service fonctionne sur le port ${PORT}`);
});
